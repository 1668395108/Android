package com.example.myapplication;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    RadioGroup rg;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button button=findViewById(R.id.td);
        rg=(RadioGroup)findViewById(R.id.rg);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                for(int i=0;i<rg.getChildCount();i++){
                    RadioButton radioButton=(RadioButton)rg.getChildAt(i);
                    if(radioButton.isChecked()){
                        if(radioButton.getText().equals("C:127")){
                            Toast.makeText(MainActivity.this, "回答正确", Toast.LENGTH_SHORT).show();
                        }else{
                            AlertDialog.Builder builder=new AlertDialog.Builder(MainActivity.this);
                            builder.setMessage("回答错误");
                            builder.setPositiveButton("确定",null).show();
                        }
                        break;
                    }
                }
            }
        });
        TextView tv=(TextView)findViewById(R.id.wang_mima);
        tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(MainActivity.this,PasswordActivity.class);
                startActivity(intent);
            }
        });


    }
}
